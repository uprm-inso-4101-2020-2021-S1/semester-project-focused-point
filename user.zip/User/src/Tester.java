public class Tester {

	public static void main(String[] args) {
		User Christopher = new User("Christopher", "1234", User.sex.MALE, 20, 134, 5, 8);

		//test getters
		System.out.println("Printing User Details...");
		System.out.println();
		System.out.println("username: " + Christopher.getUsername());
		System.out.println("password: " + Christopher.getPassword());
		System.out.println("sex: " + Christopher.uSex);
		System.out.println("age: " + Christopher.getAge());
		System.out.println("weight: " + Christopher.currentWeight() + " lb");
		System.out.println("height: " + Christopher.getHeightFT() + "'" + Christopher.getHeightIN() + "\"");
		
		System.out.println();
		System.out.println("=======================================================");
		System.out.println();
		
		//Test setters
		System.out.println("Changing Username...");
		Christopher.setUsername("Lagos");
		System.out.println("Username Changed to: " + Christopher.getUsername());
		
		System.out.println();
		
		System.out.println("Changing Password...");
		Christopher.setPassword("AppleSauce$4683");
		System.out.println("Password Changed to: " + Christopher.getPassword());
		
		Christopher.setAge(21);
		Christopher.setWeight(141);
		Christopher.setHeightFT(6);
		Christopher.setHeightIN(0);
		
		System.out.println();
		
		System.out.println("User has had the following changes after a year: ");
		System.out.println(Christopher.toString());
		
		System.out.println();
		
		System.out.println("Entry #1 yields a weight of: " + Christopher.weightAt(1) + " lb");
		System.out.println("Entry #2 yields a weight of: " + Christopher.weightAt(2) + " lb");

		
		System.out.println();
		System.out.println("=======================================================");
		System.out.println();
		
		//BMI test
		System.out.println("Calculating Users Body Mass Index...");
		double bmi = Christopher.BMI();
		System.out.println("BMI: " + bmi);
		System.out.println("A BMI of " + bmi + " classifies as " + Christopher.classifyBMI());
		
		System.out.println();
		System.out.println("=======================================================");
		System.out.println();
		
		//BFP
		System.out.println("Calculating Users Body Fat Percentage using the BMI Method...");
		System.out.println(Christopher.BFP() + "%");
		
		System.out.println();
		System.out.println("=======================================================");
		System.out.println();
		
		//Meals
		Christopher.addMeal("Philly Cheesesteak", 680);
		Christopher.addMeal("Ramen", 436);
		Christopher.addMeal("Travipatty", 630);
		
		System.out.println("Printing today's meals...");
		Christopher.ht.print(System.out);
		
		System.out.println();
		System.out.println("The User had a total of " + Christopher.ht.size() + " meals.");
	}

}
