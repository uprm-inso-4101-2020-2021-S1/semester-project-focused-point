import hashtable.HashTableFactory;
import hashtable.HashTableSCFactory;
import list.ArrayList;
import map.Map;

public class User {
	
	//private fields
	private String username, password;				
	private int age;
	private ArrayList<Integer> weight;		//Weight will be measured in pounds
	public Map<String, Double> ht;			//HashTable for calories
	private int heightFT, heightIN;			//Height will be measured in feet & inches
	public enum sex {
		MALE, FEMALE
	}
	sex uSex;
	
	public User(String un, String pw, sex uSex, int age, int weight, int heightFT, int heightIN) {
		if (weight < 1) {
			throw new IllegalArgumentException("The weight must be at least 1");
		}
		if (age < 3) {
			throw new IllegalArgumentException("Users age must be at least 3");
		}
		this.username = un;	
		this.password = pw;	
		this.uSex = uSex;
		this.age = age;
		this.weight = new ArrayList<Integer>(10);
		this.weight.add(weight);
		HashTableFactory<String, Double> factory = new HashTableSCFactory<String, Double>();
		this.ht = factory.getInstance(10);
		this.heightFT = heightFT;
		this.heightIN = heightIN;
	}
	
	public int currentWeight() {
		return this.weight.last();
	}
	
	public int weightAt(int n) {
		return this.weight.get(n-1);
	}
	
	public void setWeight(int w) {
		if (w < 1) {
			throw new IllegalArgumentException("Weight must be at least 1");
		}
		this.weight.add(w);
	}
	
	//Calculates BMI.
	public double BMI() {
		return (currentWeight()*703)/(Math.pow(heightInInches(), 2));
	}
	
	//BMI classification.
	public String classifyBMI() {
		if (BMI() <= 18.5) {
			return "UNDERWEIGHT";
		} else if (BMI() <= 24.9) {
			return "NORMAL";
		} else if (BMI() <= 29.9) {
			return "OVERWEIGHT";
		} else if (BMI() <= 35) {
			return "OBESE CLASS I";
		} else if (BMI() <= 40) {
			return "OBESE CLASS II";
		} else {
			return "OBESE CLASS III";
		}
	}
	
	//Body Fat Percentage (BMI Method)
	public double BFP () {
		if (this.age > 19) {
			if (this.uSex.equals(sex.MALE)) {
				return ((1.20*BMI())+(0.23*this.age))-16.2;
			} else {
				return ((1.20*BMI())+(0.23*this.age))-5.2;
			}
		}
		if (this.uSex.equals(sex.MALE)) {
			return ((1.51*BMI())-(0.7*this.age))-2.2;
		} else {
		return (1.51*BMI())-(0.7*(this.age))-1.4;
		}
	}
	
	//Transfers the heightFT to inches and adds the remaining inches from heightIN. 
	public int heightInInches() {
		return (heightFT*12)+heightIN;
	}
	
	public void addMeal(String food, double cal) {
		this.ht.put(food, cal);
	}
	
	//getters & setters
	public String getUsername() { 
		return username;
	}
	
	public void setUsername(String un) {
		this.username = un;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String pw) {
		this.password = pw;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int a) {
		this.age = a; 
	}
	
	//getters & setters for height
	public int getHeightFT() {
		return heightFT;
	}
	
	public void setHeightFT(int ft) {
		this.heightFT = ft;
	}
	
	public int getHeightIN() {
		 return heightIN;
	}
	
	public void setHeightIN(int in) {
		this.heightIN = in;
	}
	
	public String toString() {
		return "(" + username + ", " + password + ", " + uSex + ", " + age + " yrs, " 
				+ currentWeight() + " lb, " + heightFT + "'" + heightIN + "\")";
	}
}
